<!-- begin sidebar -->

<div id="sidebar">

	
	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(1) ) : else : ?>
	

		
	<?php endif; ?>



		
</div>

<!-- end sidebar -->